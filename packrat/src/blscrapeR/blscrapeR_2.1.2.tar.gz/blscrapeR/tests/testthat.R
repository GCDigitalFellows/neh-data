library(testthat)
library(blscrapeR)

test_check("blscrapeR")
